import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  _tituloNavBar: string = 'Mi primer Navbar';
  _menuCierraSesionBoolean: boolean = false;

  constructor() { }

  ngOnInit(): void {
    
  }

  btnDetalles(){
    console.log('Click en el boton de detalle');
  }

}
